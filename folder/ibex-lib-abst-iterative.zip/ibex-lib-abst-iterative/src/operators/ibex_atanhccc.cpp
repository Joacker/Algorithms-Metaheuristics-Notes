//============================================================================
//                                  I B E X
// File        : ibex_atanhccc.cpp
// Author      : Gilles Chabert
// Copyright   : IMT Atlantique (France)
// License     : See the LICENSE file
// Created     : Oct 05, 2018
//============================================================================

namespace ibex {

extern const char ATANHCCC[] = "atanhccc";

} // end namespace
