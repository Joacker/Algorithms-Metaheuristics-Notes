//============================================================================
//                                  I B E X
// File        : ibex_ExprCopy.h
// Author      : Gilles Chabert
// Copyright   : IMT Atlantique (France)
// License     : See the LICENSE file
// Created     : Mar 2, 2020
//============================================================================

#ifndef __IBEX_EXPR_INPUT_NODE_MAP_H__
#define __IBEX_EXPR_INPUT_NODE_MAP_H__

#include "ibex_NodeMap.h"

namespace ibex {

//class InputNodeMap : public NodeMap<const ExprNode*> {
//public:
//	InputNodeMap(const Array<const ExprSymbol>& old_x, const Array<const ExprSymbol>& new_x);
//
//	InputNodeMap(const Array<const ExprSymbol>& old_x, const Array<const ExprNode>& new_x);
//	//const ExprNode& get_arg(const ExprSymbol&);
//
//	//const ExprNode& get_mutable_cst(const ExprConstant&);
//
//	InputNodeMap();
//	virtual ~InputNodeMap();
//};

} /* namespace ibex */

#endif /* S__IBEX_EXPR_INPUT_NODE_MAP_H__ */
