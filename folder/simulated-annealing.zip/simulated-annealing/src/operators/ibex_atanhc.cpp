//============================================================================
//                                  I B E X
// File        : ibex_atanhc.cpp
// Author      : Gilles Chabert
// Copyright   : IMT Atlantique (France)
// License     : See the LICENSE file
// Created     : Oct 05, 2018
//============================================================================

namespace ibex {

extern const char ATANHC[] = "atanhc";

} // end namespace
