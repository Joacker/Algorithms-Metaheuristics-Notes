The LBFGS++ library was adapted from the libLBFGS library
(https://github.com/chokkan/liblbfgs), written by
Naoaki Okazaki <<okazaki@c.titech.ac.jp>>.

The files

- `include/LBFGS/LineSearchBracketing.h`
- `include/LBFGS/LineSearchNocedalWright.h`

were contributed by Dirk Toewe <<DirkToewe@GoogleMail.com>>.

Other part of LBFGS++ was written by Yixuan Qiu <<yixuan.qiu@cos.name>>.
